// Fetch the options from the server and populate the dropdowns
document.addEventListener("DOMContentLoaded", function() {
    fetch('/get_options')
        .then(response => response.json())
        .then(data => {
            for (let key in data) {
                let selectElement = document.getElementById(key);
                if (selectElement) {
                    data[key].forEach(option => {
                        let opt = document.createElement('option');
                        opt.value = option;
                        opt.textContent = option;
                        selectElement.appendChild(opt);
                    });
                }
            }
        })
        .catch(error => console.error('Error fetching options:', error));
});
const resultDiv = document.getElementById('result');
resultDiv.innerHTML = ""; // Clear previous content
if (data.predicted_future_career) {
    resultDiv.textContent = `HEY THERE, YOU WILL DO GREAT AS : ${data.predicted_future_career}`;
    resultDiv.classList.add('show');
} else {
    resultDiv.textContent = "OOPS! YOUR PROFILE IS BEYOND THE CAPABILITIES OF OUR UNDERSTANDING";
    resultDiv.classList.add('show');
}
